
// FIREBASE IS DEPRECATED IN FAVOR OF MONGODB
// This file is kept as a placeholder to prevent import errors in legacy code, 
// but it exports nothing useful.
export const db = null;
export const auth = null;
export const functions = null;
export const getMaskedApiKey = () => "MONGODB_MODE";
